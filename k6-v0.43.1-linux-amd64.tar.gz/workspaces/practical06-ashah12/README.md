[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-f4981d0f882b2a3f0472912d15f9806d57e124e0fc890972558857b51b24a6f9.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=10667917)
# CSSE6400 Week 6 Practical

Deploying our TaskOverflow application to EC2/ECS instances with a load balancer on AWS using Terraform.

Please see the [instructions](https://csse6400.uqcloud.net/practicals/week06.pdf) for more details.

Update this README file with appropriate information about your project,
including how to run it.

There are [resources](https://www.makeareadme.com) available to help you write a good README file.